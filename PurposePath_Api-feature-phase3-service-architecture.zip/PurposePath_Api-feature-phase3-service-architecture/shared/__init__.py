"""Canonical shared package for cross-service models and services."""

__all__: list[str] = []
