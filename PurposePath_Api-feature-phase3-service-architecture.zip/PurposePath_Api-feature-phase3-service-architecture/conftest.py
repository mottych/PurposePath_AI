"""Global pytest configuration for dynamic service resolution."""
import os

os.environ.setdefault("PURPOSEPATH_SERVICE", "account")

